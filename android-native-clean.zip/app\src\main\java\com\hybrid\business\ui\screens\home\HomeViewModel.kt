package com.hybrid.business.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hybrid.business.data.local.entity.TransactionEntity
import com.hybrid.business.data.repository.BusinessRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

data class HomeUiState(
    val balance: Double = 0.0,
    val income: Double = 0.0,
    val expense: Double = 0.0,
    val total: Double = 0.0,
    val due: Double = 0.0,
    val projectCount: Int = 0,
    val recent: List<TransactionEntity> = emptyList()
)

@HiltViewModel
class HomeViewModel @Inject constructor(repo: BusinessRepository) : ViewModel() {
    val uiState: StateFlow<HomeUiState> = combine(
        repo.observeTransactions(),
        repo.observeWorkers(),
        repo.observeProjects()
    ) { txs, workers, projects ->
        val inc = txs.filter { it.type == "income" }.sumOf { it.amount }
        val exp = txs.filter { it.type == "expense" }.sumOf { it.amount }
        HomeUiState(
            balance = inc - exp,
            income = inc,
            expense = exp,
            total = inc + exp,
            due = workers.filter { it.status == "active" && it.totalDue > 0 }.sumOf { it.totalDue },
            projectCount = projects.size,
            recent = txs.take(8)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUiState())
}
