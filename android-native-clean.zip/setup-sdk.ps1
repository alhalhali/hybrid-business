# Hybrid Business - Setup SDK خفيف بدون Android Studio
# شغّل هذا الملف كـ PowerShell (كليك يمين -> Run with PowerShell)
$ErrorActionPreference = "Stop"

$androidHome = "C:\Android"
$cmdlineUrl = "https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip"
$zipPath = "$env:TEMP\cmdline-tools.zip"
$gradleVersion = "8.7"
$gradleUrl = "https://services.gradle.org/distributions/gradle-$gradleVersion-bin.zip"
$gradleZip = "$env:TEMP\gradle-$gradleVersion-bin.zip"

Write-Host "=== 1/4 فحص Java ===" -ForegroundColor Cyan
try { java -version } catch { Write-Host "❌ Java غير موجود، حمل JDK 17 من adoptium.net" -ForegroundColor Red; pause; exit }

Write-Host "`n=== 2/4 تحميل Command line tools (150MB) ===" -ForegroundColor Cyan
# تخزين مؤقت لمنع إعادة التحميل كل مرة
$cacheDir = "$androidHome\.cache"
New-Item -ItemType Directory -Force -Path $cacheDir | Out-Null
$cachedZip = "$cacheDir\cmdline-tools.zip"
if (!(Test-Path "$androidHome\cmdline-tools\latest\bin\sdkmanager.bat")) {
    New-Item -ItemType Directory -Force -Path $androidHome | Out-Null
    if (Test-Path $cachedZip) {
        Write-Host "استخدام النسخة المحفوظة مؤقتاً..." -ForegroundColor Yellow
        Copy-Item $cachedZip $zipPath -Force
    } else {
        Write-Host "جاري التحميل من dl.google.com ..."
        Invoke-WebRequest -Uri $cmdlineUrl -OutFile $zipPath -UseBasicParsing
        Copy-Item $zipPath $cachedZip -Force
    }
    Write-Host "فك الضغط..."
    Expand-Archive -Path $zipPath -DestinationPath "$env:TEMP\cmdline-temp" -Force
    New-Item -ItemType Directory -Force -Path "$androidHome\cmdline-tools" | Out-Null
    if (Test-Path "$androidHome\cmdline-tools\latest") { Remove-Item -Recurse -Force "$androidHome\cmdline-tools\latest" }
    Move-Item "$env:TEMP\cmdline-temp\cmdline-tools" "$androidHome\cmdline-tools\latest" -Force
    Remove-Item -Recurse -Force "$env:TEMP\cmdline-temp" -ErrorAction SilentlyContinue
    Remove-Item $zipPath -ErrorAction SilentlyContinue
    Write-Host "✅ تم تثبيت cmdline-tools" -ForegroundColor Green
} else { Write-Host "موجود مسبقاً - تخطي التحميل" -ForegroundColor Green }

# إضافة متغيرات البيئة للجلسة الحالية
$env:ANDROID_HOME = $androidHome
$env:ANDROID_SDK_ROOT = $androidHome
$env:Path += ";$androidHome\cmdline-tools\latest\bin;$androidHome\platform-tools"

Write-Host "`n=== 3/4 تثبيت منصات Android المطلوبة ===" -ForegroundColor Cyan
# فحص المثبت مسبقاً لتجنب إعادة التحميل
$installed = & "$androidHome\cmdline-tools\latest\bin\sdkmanager.bat" --list_installed 2>$null | Out-String
$packages = @("platform-tools","platforms;android-34","build-tools;34.0.0")
foreach ($pkg in $packages) {
    if ($installed -match [regex]::Escape($pkg)) {
        Write-Host "موجود مسبقاً - تخطي $pkg" -ForegroundColor Green
    } else {
        Write-Host "تثبيت $pkg ..."
        Start-Process -FilePath "$androidHome\cmdline-tools\latest\bin\sdkmanager.bat" -ArgumentList "`"$pkg`"" -Wait -NoNewWindow
    }
}

Write-Host "`nقبول التراخيص..."
if (!(Test-Path "$androidHome\licenses\android-sdk-license")) {
    "y`ny`ny`ny`n" | & "$androidHome\cmdline-tools\latest\bin\sdkmanager.bat" --licenses | Out-Null
} else { Write-Host "التراخيص مقبولة مسبقاً" -ForegroundColor Green }

Write-Host "`n=== 4/4 تجهيز Gradle Wrapper ===" -ForegroundColor Cyan
$projectDir = $PSScriptRoot
$cachedGradleZip = "$cacheDir\gradle-$gradleVersion-bin.zip"
if (!(Test-Path "$projectDir\gradlew.bat")) {
    if (Test-Path $cachedGradleZip) {
        Write-Host "استخدام Gradle المحفوظ..." -ForegroundColor Yellow
        Copy-Item $cachedGradleZip $gradleZip -Force
    } else {
        Write-Host "تحميل Gradle $gradleVersion ..."
        Invoke-WebRequest -Uri $gradleUrl -OutFile $gradleZip -UseBasicParsing
        Copy-Item $gradleZip $cachedGradleZip -Force
    }
    Expand-Archive -Path $gradleZip -DestinationPath "$env:TEMP" -Force
    $gradleBin = "$env:TEMP\gradle-$gradleVersion\bin\gradle.bat"
    Write-Host "إنشاء wrapper..."
    Push-Location $projectDir
    & $gradleBin wrapper --gradle-version $gradleVersion
    Pop-Location
    Remove-Item $gradleZip -ErrorAction SilentlyContinue
    Remove-Item -Recurse -Force "$env:TEMP\gradle-$gradleVersion" -ErrorAction SilentlyContinue
    Write-Host "✅ تم إنشاء gradlew" -ForegroundColor Green
} else { Write-Host "gradlew موجود - تخطي" -ForegroundColor Green }

Write-Host "`n✅ انتهى التجهيز! شغل الآن: .\build-apk.ps1" -ForegroundColor Green
pause
