package com.hybrid.business.ui.screens.sales

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hybrid.business.data.local.entity.SaleEntity
import com.hybrid.business.data.repository.BusinessRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SalesViewModel @Inject constructor(private val repo: BusinessRepository) : ViewModel() {
    val sales = repo.observeSales()
    val products = repo.observeProducts()
    val customers = repo.observeCustomers()

    private fun today(): String = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
    fun addSale(productId: Long, quantity: Double, unitPrice: Double, customerId: Long?) = viewModelScope.launch {
        val subtotal = quantity * unitPrice
        repo.addSale(SaleEntity(productId=productId, quantity=quantity, unitPrice=unitPrice, subtotal=subtotal, total=subtotal, date = today(), customerId = customerId))
        // خصم من المخزون
        val product = repo.getProductById(productId) ?: return@launch
        repo.updateProductQuantity(productId, (product.quantity - quantity).coerceAtLeast(0.0))
    }
    fun deleteSale(id: Long) = viewModelScope.launch { repo.deleteSale(id) }
}
