package com.hybrid.business.ui.screens.workers

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.hybrid.business.util.formatCurrency

@Composable
fun WorkersScreen(vm: WorkersViewModel = hiltViewModel()) {
    val workers by vm.workers.collectAsState(emptyList())
    var showDialog by remember { mutableStateOf(false) }
    Scaffold(floatingActionButton = { FloatingActionButton(onClick = {showDialog=true}) { Icon(Icons.Filled.Add, null) } }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(workers) { w ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(w.name, style = MaterialTheme.typography.titleMedium)
                        Text("${w.role} • ${w.status} • ${formatCurrency(w.rate)}")
                        Text("مستحق: ${formatCurrency(w.totalDue)}", color = if(w.totalDue>0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        if(showDialog) AddWorkerDialog(onDismiss = {showDialog=false}, onSave = { name, role, rate -> vm.addWorker(name, role, rate); showDialog=false })
    }
}

@Composable
private fun AddWorkerDialog(onDismiss: ()->Unit, onSave: (String,String,Double)->Unit){
    var name by remember{ mutableStateOf("") }
    var rate by remember{ mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = {Text("إضافة عامل")},
        text = { Column{ OutlinedTextField(name, {name=it}, label={Text("الاسم")}); OutlinedTextField(rate, {rate=it}, label={Text("الأجر")}) } },
        confirmButton = { TextButton(onClick = {onSave(name,"general", rate.toDoubleOrNull()?:0.0)}){Text("حفظ")} },
        dismissButton = { TextButton(onClick = onDismiss){Text("إلغاء")} }
    )
}
