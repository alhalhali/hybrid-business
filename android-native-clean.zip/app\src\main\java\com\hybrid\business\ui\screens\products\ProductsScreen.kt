package com.hybrid.business.ui.screens.products

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.hybrid.business.util.formatCurrency

@Composable
fun ProductsScreen(vm: ProductsViewModel = hiltViewModel()) {
    val products by vm.products.collectAsState(emptyList())
    var search by remember { mutableStateOf("") }
    var showDialog by remember { mutableStateOf(false) }
    val filtered = products.filter { it.name.contains(search, true) || it.sku.contains(search, true) }
    Scaffold(floatingActionButton = { FloatingActionButton(onClick = { showDialog = true }) { Icon(Icons.Filled.Add, null) } }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Text("المنتجات", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(search, { search = it }, label = { Text("بحث...") }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(Modifier.weight(1f)) { Column(Modifier.padding(12.dp)) { Text("عدد المنتجات", style = MaterialTheme.typography.labelSmall); Text("${products.size}", style = MaterialTheme.typography.titleLarge) } }
                Card(Modifier.weight(1f)) { Column(Modifier.padding(12.dp)) { Text("قيمة المخزون", style = MaterialTheme.typography.labelSmall); Text(formatCurrency(products.sumOf { it.quantity * it.costPrice }), style = MaterialTheme.typography.titleMedium) } }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top=12.dp)) {
                items(filtered) { p ->
                    val low = p.quantity <= p.minQuantity
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if(low) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                        Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column { Text(p.name, style = MaterialTheme.typography.titleSmall); Text("${p.quantity} ${p.unit} • ${formatCurrency(p.salePrice)}", style = MaterialTheme.typography.bodySmall) }
                            IconButton(onClick = { vm.deleteProduct(p.id) }) { Icon(Icons.Filled.Delete, null) }
                        }
                    }
                }
            }
        }
        if(showDialog){
            var name by remember{ mutableStateOf("") }
            var price by remember{ mutableStateOf("") }
            var qty by remember{ mutableStateOf("") }
            AlertDialog(onDismissRequest={showDialog=false}, title={Text("منتج جديد")},
                text={ Column(verticalArrangement= Arrangement.spacedBy(8.dp)){ OutlinedTextField(name,{name=it}, label={Text("الاسم")}); OutlinedTextField(price,{price=it}, label={Text("سعر البيع")}); OutlinedTextField(qty,{qty=it}, label={Text("الكمية")}) } },
                confirmButton={ TextButton(onClick={vm.addProduct(name, price.toDoubleOrNull()?:0.0, qty.toDoubleOrNull()?:0.0); showDialog=false}){Text("حفظ")} },
                dismissButton={ TextButton(onClick={showDialog=false}){Text("إلغاء")} }
            )
        }
    }
}
