package com.hybrid.business.ui.screens.accounting

import androidx.lifecycle.ViewModel
import com.hybrid.business.data.repository.BusinessRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class AccountingViewModel @Inject constructor(repo: BusinessRepository) : ViewModel() {
    val transactions = repo.observeTransactions()
    val journal = repo.observeJournal()
}
