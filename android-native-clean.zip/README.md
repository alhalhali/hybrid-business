# Hybrid Business OS - Native Kotlin

تحويل حقيقي من `source_index.html` الى `Kotlin + Room + Jetpack Compose`

## الهيكل
- `data/local/entity` : 17 جدول Room (مطابق لـ SCHEMA_VERSION=8)
- `data/local/dao` : DAOs مع Flow
- `security/CryptoManager` : AES-256-GCM بديل encryptAES() في HTML
- `ui/screens/*` : Compose Screens بديل كل page-* في HTML
- `ui/navigation/NavGraph` : بديل switchPage()

## البناء
```bash
cd android-native
./gradlew assembleDebug        # APK debug
./gradlew assembleRelease      # AAB للمتجر
```

## الاستيراد من النسخة القديمة
1. من التطبيق HTML: الإعدادات -> تصدير JSON
2. في التطبيق الجديد: سيتم قراءة الملف عبر `prepopulate` وتحويله الى Room

## المميزات المنقولة
- PIN 4 أرقام + تشفير AES-256
- 17 جدول: transactions, workers, projects+phases, customers, products, sales, purchases, suppliers, inventory, attendance, daily_journals, payments, accounts, journal_entries
- RTL + Tajawal + ثيم #0f766e

## الخطوة القادمة
- إضافة Hilt ViewModels لكل شاشة عمليات (مخزون، حضور، دفعات)
- تفعيل Backup/Restore عبر DataStore
