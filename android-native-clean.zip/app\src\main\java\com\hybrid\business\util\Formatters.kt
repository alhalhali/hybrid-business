package com.hybrid.business.util

import java.text.NumberFormat
import java.util.Locale

fun formatCurrency(amount: Double, currency: String = "YER"): String {
    val locale = if (currency == "USD") Locale.US else Locale("ar", "SA")
    val symbol = when(currency){ "YER"->"ر.ي"; "SAR"->"ر.س"; "USD"->"$"; "AED"->"د.إ"; else->currency }
    return NumberFormat.getNumberInstance(locale).apply { maximumFractionDigits = 2 }.format(amount) + " $symbol"
}

fun calcProjectHealth(exp: Double, budget: Double, net: Double): Int {
    var score = 50
    if (budget > 0) {
        val u = exp / budget
        score += when { u <= 0.5 -> 25; u <= 0.8 -> 15; u <= 1.0 -> 5; else -> -((u-1)*30).toInt().coerceAtMost(30) }
    }
    score += if (net > 0) 20 else -15
    return score.coerceIn(0, 100)
}
