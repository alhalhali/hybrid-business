package com.hybrid.business.data.local

import com.hybrid.business.data.local.entity.*
import org.json.JSONObject

object JsonImporter {
    // يقرأ ملف JSON المصدر من HTML (JSON.stringify(state)) و يحوله لـ Entities
    fun parse(json: String): ImportBundle {
        val root = JSONObject(json)
        val transactions = mutableListOf<TransactionEntity>()
        val workers = mutableListOf<WorkerEntity>()
        val projects = mutableListOf<ProjectEntity>()
        val customers = mutableListOf<CustomerEntity>()
        val products = mutableListOf<ProductEntity>()
        val sales = mutableListOf<SaleEntity>()
        val purchases = mutableListOf<PurchaseEntity>()

        root.optJSONArray("transactions")?.let { arr ->
            for(i in 0 until arr.length()){
                val o = arr.getJSONObject(i)
                transactions.add(TransactionEntity(
                    type = o.optString("type","expense"),
                    amount = o.optDouble("amount",0.0),
                    category = o.optString("category",""),
                    description = o.optString("description",""),
                    date = o.optString("date",""),
                    workerId = o.optLong("workerId").takeIf{it!=0L},
                    projectId = o.optLong("projectId").takeIf{it!=0L},
                    taxRate = o.optDouble("taxRate",0.0)
                ))
            }
        }
        root.optJSONArray("workers")?.let { arr ->
            for(i in 0 until arr.length()){
                val o = arr.getJSONObject(i)
                workers.add(WorkerEntity(
                    name = o.optString("name",""),
                    role = o.optString("role","general"),
                    status = o.optString("status","active"),
                    type = o.optString("type","daily"),
                    rate = o.optDouble("rate",0.0),
                    totalDue = o.optDouble("totalDue",0.0),
                    phone = o.optString("phone",""),
                    notes = o.optString("notes","")
                ))
            }
        }
        root.optJSONArray("projects")?.let { arr ->
            for(i in 0 until arr.length()){
                val o = arr.getJSONObject(i)
                projects.add(ProjectEntity(
                    name = o.optString("name",""),
                    client = o.optString("client",""),
                    budget = o.optDouble("budget",0.0),
                    contractValue = o.optDouble("contractValue",0.0),
                    priority = o.optString("priority","medium"),
                    startDate = o.optString("startDate",""),
                    endDate = o.optString("endDate","")
                ))
            }
        }
        root.optJSONArray("customers")?.let { arr ->
            for(i in 0 until arr.length()){
                val o = arr.getJSONObject(i)
                customers.add(CustomerEntity(
                    name = o.optString("name",""),
                    phone = o.optString("phone",""),
                    email = o.optString("email",""),
                    balance = o.optDouble("balance",0.0),
                    openingBalance = o.optDouble("openingBalance",0.0)
                ))
            }
        }
        root.optJSONArray("products")?.let { arr ->
            for(i in 0 until arr.length()){
                val o = arr.getJSONObject(i)
                products.add(ProductEntity(
                    name = o.optString("name",""),
                    sku = o.optString("sku",""),
                    unit = o.optString("unit","قطعة"),
                    salePrice = o.optDouble("salePrice",0.0),
                    costPrice = o.optDouble("costPrice",0.0),
                    quantity = o.optDouble("quantity",0.0)
                ))
            }
        }
        root.optJSONArray("sales")?.let { arr ->
            for(i in 0 until arr.length()){
                val o = arr.getJSONObject(i)
                sales.add(SaleEntity(
                    invoiceNo = o.optString("invoiceNo",""),
                    productName = o.optString("productName",""),
                    quantity = o.optDouble("quantity",0.0),
                    unitPrice = o.optDouble("unitPrice",0.0),
                    total = o.optDouble("total",0.0),
                    date = o.optString("date","")
                ))
            }
        }
        root.optJSONArray("purchases")?.let { arr ->
            for(i in 0 until arr.length()){
                val o = arr.getJSONObject(i)
                purchases.add(PurchaseEntity(
                    supplier = o.optString("supplier",""),
                    item = o.optString("item",""),
                    quantity = o.optDouble("quantity",0.0),
                    unitCost = o.optDouble("unitCost",0.0),
                    total = o.optDouble("total",0.0),
                    date = o.optString("date","")
                ))
            }
        }
        return ImportBundle(transactions, workers, projects, customers, products, sales, purchases)
    }

    data class ImportBundle(
        val transactions: List<TransactionEntity>,
        val workers: List<WorkerEntity>,
        val projects: List<ProjectEntity>,
        val customers: List<CustomerEntity>,
        val products: List<ProductEntity>,
        val sales: List<SaleEntity>,
        val purchases: List<PurchaseEntity>
    )
}
