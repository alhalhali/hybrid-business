package com.hybrid.business.data.repository

import com.hybrid.business.data.local.AppDatabase
import com.hybrid.business.data.local.entity.*
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BusinessRepository @Inject constructor(private val db: AppDatabase) {

    // Transactions
    fun observeTransactions(): Flow<List<TransactionEntity>> = db.transactionDao().observeAll()
    suspend fun addTransaction(e: TransactionEntity) = db.transactionDao().insert(e)
    suspend fun deleteTransaction(id: Long) = db.transactionDao().deleteById(id)

    // Workers
    fun observeWorkers() = db.workerDao().observeAll()
    suspend fun addWorker(e: WorkerEntity) = db.workerDao().insert(e)
    suspend fun deleteWorker(id: Long) = db.workerDao().deleteById(id)

    // Projects + Phases
    fun observeProjects() = db.projectDao().observeAll()
    fun observePhases(projectId: Long) = db.phaseDao().observeByProject(projectId)
    suspend fun addProject(p: ProjectEntity, phases: List<PhaseEntity>): Long {
        val id = db.projectDao().insert(p)
        phases.forEach { db.phaseDao().insert(it.copy(projectId = id)) }
        return id
    }

    // Customers / Products / Sales / Purchases
    fun observeCustomers() = db.customerDao().observeAll()
    fun observeProducts() = db.productDao().observeAll()
    fun observeSales() = db.saleDao().observeAll()
    fun observePurchases() = db.purchaseDao().observeAll()
    fun observeSuppliers() = db.supplierDao().observeAll()

    suspend fun addCustomer(e: CustomerEntity) = db.customerDao().insert(e)
    suspend fun deleteCustomer(id: Long) = db.customerDao().deleteById(id)
    suspend fun addProduct(e: ProductEntity) = db.productDao().insert(e)
    suspend fun deleteProduct(id: Long) = db.productDao().deleteById(id)
    suspend fun getProductById(id: Long) = db.productDao().getById(id)
    suspend fun updateProductQuantity(id: Long, qty: Double) = db.productDao().updateQuantity(id, qty)
    suspend fun addSale(e: SaleEntity) = db.saleDao().insert(e)
    suspend fun deleteSale(id: Long) = db.saleDao().deleteById(id)
    suspend fun addPurchase(e: PurchaseEntity) = db.purchaseDao().insert(e)
    suspend fun deletePurchase(id: Long) = db.purchaseDao().deleteById(id)

    // Import
    suspend fun clearAndImport(
        transactions: List<TransactionEntity>,
        workers: List<WorkerEntity>,
        projects: List<ProjectEntity>,
        customers: List<CustomerEntity>,
        products: List<ProductEntity>,
        sales: List<SaleEntity>,
        purchases: List<PurchaseEntity>
    ) {
        db.clearAllTables()
        transactions.forEach { db.transactionDao().insert(it.copy(id=0)) }
        workers.forEach { db.workerDao().insert(it.copy(id=0)) }
        projects.forEach { db.projectDao().insert(it.copy(id=0)) }
        customers.forEach { db.customerDao().insert(it.copy(id=0)) }
        products.forEach { db.productDao().insert(it.copy(id=0)) }
        sales.forEach { db.saleDao().insert(it.copy(id=0)) }
        purchases.forEach { db.purchaseDao().insert(it.copy(id=0)) }
    }

    // Accounting
    fun observeAccounts() = db.accountDao().observeAll()
    fun observeJournal() = db.journalDao().observeEntries()
    suspend fun postJournal(entry: JournalEntryEntity, lines: List<JournalLineEntity>): Long {
        val entryId = db.journalDao().insertEntry(entry)
        db.journalDao().insertLines(lines.map { it.copy(entryId = entryId) })
        return entryId
    }
    suspend fun voidJournal(id: Long) = db.journalDao().voidEntry(id)
}
