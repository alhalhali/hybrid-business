package com.hybrid.business.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.hybrid.business.data.local.dao.*
import com.hybrid.business.data.local.entity.*

@Database(
    entities = [
        TransactionEntity::class, WorkerEntity::class, ProjectEntity::class, PhaseEntity::class,
        CustomerEntity::class, ProductEntity::class, WarehouseEntity::class, SaleEntity::class,
        PurchaseEntity::class, SupplierEntity::class,
        DailyJournalEntity::class, AttendanceEntity::class, PaymentEntity::class,
        InventoryEntity::class, AccountEntity::class, JournalEntryEntity::class, JournalLineEntity::class
    ],
    version = 8,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun workerDao(): WorkerDao
    abstract fun projectDao(): ProjectDao
    abstract fun phaseDao(): PhaseDao
    abstract fun customerDao(): CustomerDao
    abstract fun productDao(): ProductDao
    abstract fun saleDao(): SaleDao
    abstract fun purchaseDao(): PurchaseDao
    abstract fun supplierDao(): SupplierDao
    abstract fun accountDao(): AccountDao
    abstract fun journalDao(): JournalDao
}
