package com.hybrid.business.ui.screens.sales

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.hybrid.business.util.formatCurrency

@Composable
fun SalesScreen(vm: SalesViewModel = hiltViewModel()) {
    val sales by vm.sales.collectAsState(emptyList())
    val products by vm.products.collectAsState(emptyList())
    var showDialog by remember { mutableStateOf(false) }

    Scaffold(floatingActionButton = { FloatingActionButton(onClick = { showDialog = true }) { Icon(Icons.Filled.Add, null) } }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Text("المبيعات", style = MaterialTheme.typography.titleLarge)
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(Modifier.weight(1f)) { Column(Modifier.padding(12.dp)) { Text("عدد العمليات", style = MaterialTheme.typography.labelSmall); Text("${sales.size}", style = MaterialTheme.typography.titleLarge) } }
                Card(Modifier.weight(1f)) { Column(Modifier.padding(12.dp)) { Text("إجمالي المبيعات", style = MaterialTheme.typography.labelSmall); Text(formatCurrency(sales.sumOf { it.total }), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary) } }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sales) { s ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column { Text(s.invoiceNo.ifEmpty { "فاتورة #${s.id}" }, style = MaterialTheme.typography.titleSmall); Text("${s.productName} • ${s.quantity} × ${formatCurrency(s.unitPrice)}", style = MaterialTheme.typography.bodySmall) }
                            Text(formatCurrency(s.total), color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
        if(showDialog){
            var qty by remember{ mutableStateOf("1") }
            var selectedProduct by remember{ mutableStateOf<Long?>(null) }
            AlertDialog(
                onDismissRequest = { showDialog = false },
                title = { Text("بيع جديد") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("اختر المنتج:")
                        products.take(5).forEach { p ->
                            FilterChip(selected = selectedProduct==p.id, onClick = { selectedProduct = p.id }, label = { Text("${p.name} (${p.quantity})") })
                        }
                        OutlinedTextField(qty, { qty = it }, label = { Text("الكمية") })
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val pid = selectedProduct ?: products.firstOrNull()?.id ?: return@TextButton
                        val q = qty.toDoubleOrNull() ?: 1.0
                        val price = products.find { it.id==pid }?.salePrice ?: 0.0
                        vm.addSale(pid, q, price, null); showDialog=false
                    }) { Text("حفظ") }
                },
                dismissButton = { TextButton(onClick={showDialog=false}){Text("إلغاء")} }
            )
        }
    }
}
