package com.hybrid.business.ui.screens.workers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hybrid.business.data.local.entity.WorkerEntity
import com.hybrid.business.data.repository.BusinessRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class WorkersViewModel @Inject constructor(private val repo: BusinessRepository) : ViewModel() {
    val workers = repo.observeWorkers()
    fun addWorker(name: String, role: String, rate: Double) = viewModelScope.launch {
        repo.addWorker(WorkerEntity(name=name, role=role, rate=rate))
    }
    fun deleteWorker(id: Long) = viewModelScope.launch { repo.deleteWorker(id) }
}
