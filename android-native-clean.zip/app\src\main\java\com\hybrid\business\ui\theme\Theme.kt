package com.hybrid.business.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Primary = Color(0xFF0F766E)
private val PrimaryDark = Color(0xFF115E59)
private val Accent = Color(0xFFD97706)

private val LightScheme = lightColorScheme(
    primary = Primary,
    secondary = Accent,
    surface = Color(0xFFF0FDFA),
    background = Color(0xFFF0FDFA)
)

@Composable
fun HybridTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightScheme, content = content)
}
