package com.hybrid.business.ui.screens.customers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hybrid.business.data.local.entity.CustomerEntity
import com.hybrid.business.data.repository.BusinessRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CustomersViewModel @Inject constructor(private val repo: BusinessRepository) : ViewModel() {
    val customers = repo.observeCustomers()
    fun addCustomer(name: String, phone: String, balance: Double) = viewModelScope.launch {
        repo.addCustomer(CustomerEntity(name=name, phone=phone, balance=balance, openingBalance = balance))
    }
    fun deleteCustomer(id: Long) = viewModelScope.launch { repo.deleteCustomer(id) }
}
