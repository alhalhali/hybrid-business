package com.hybrid.business.ui.screens.customers

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.hybrid.business.util.formatCurrency

@Composable
fun CustomersScreen(vm: CustomersViewModel = hiltViewModel()) {
    val customers by vm.customers.collectAsState(emptyList())
    var showDialog by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    val filtered = customers.filter { it.name.contains(search, true) || it.phone.contains(search) }

    Scaffold(floatingActionButton = { FloatingActionButton(onClick = { showDialog = true }) { Icon(Icons.Filled.Add, null) } }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Text("العملاء", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("بحث...") }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(Modifier.weight(1f)) { Column(Modifier.padding(12.dp)) { Text("عدد العملاء", style = MaterialTheme.typography.labelSmall); Text("${customers.size}", style = MaterialTheme.typography.titleLarge) } }
                Card(Modifier.weight(1f)) { Column(Modifier.padding(12.dp)) { Text("إجمالي الأرصدة", style = MaterialTheme.typography.labelSmall); Text(formatCurrency(customers.sumOf { it.balance }), style = MaterialTheme.typography.titleMedium) } }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 12.dp)) {
                items(filtered) { c ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column { Text(c.name, style = MaterialTheme.typography.titleSmall); Text(c.phone.ifEmpty { "بدون هاتف" }, style = MaterialTheme.typography.bodySmall) }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(formatCurrency(c.balance), color = MaterialTheme.colorScheme.primary)
                                IconButton(onClick = { vm.deleteCustomer(c.id) }) { Icon(Icons.Filled.Delete, null) }
                            }
                        }
                    }
                }
            }
        }
        if (showDialog) {
            var name by remember { mutableStateOf("") }
            var phone by remember { mutableStateOf("") }
            var balance by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showDialog = false },
                title = { Text("إضافة عميل") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(name, { name = it }, label = { Text("اسم العميل") })
                        OutlinedTextField(phone, { phone = it }, label = { Text("الهاتف") })
                        OutlinedTextField(balance, { balance = it }, label = { Text("الرصيد الافتتاحي") })
                    }
                },
                confirmButton = { TextButton(onClick = { vm.addCustomer(name, phone, balance.toDoubleOrNull() ?: 0.0); showDialog = false }) { Text("حفظ") } },
                dismissButton = { TextButton(onClick = { showDialog = false }) { Text("إلغاء") } }
            )
        }
    }
}
