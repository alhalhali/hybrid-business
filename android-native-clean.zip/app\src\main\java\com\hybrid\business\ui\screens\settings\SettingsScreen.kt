package com.hybrid.business.ui.screens.settings

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun SettingsScreen(vm: SettingsViewModel = hiltViewModel()) {
    val msg by vm.msg.collectAsState("")
    var pin by remember { mutableStateOf("") }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) vm.importJson(uri, pin.ifEmpty { null })
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("الإعدادات والاستيراد", style = MaterialTheme.typography.titleLarge)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("استيراد نسخة HTML القديمة", style = MaterialTheme.typography.titleMedium)
                Text("اختر ملف JSON المصدر من التطبيق القديم (تصدير JSON). إذا كانت النسخة مشفرة أدخل PIN أولاً.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = pin, onValueChange = { pin = it }, label = { Text("PIN (إن وجد)") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { launcher.launch("application/json") }, modifier = Modifier.fillMaxWidth()) { Text("📂 اختيار ملف JSON") }
                if (msg.isNotEmpty()) Text(msg, color = if (msg.startsWith("✅")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }
        }
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
            Column(Modifier.padding(16.dp)) {
                Text("معلومات", style = MaterialTheme.typography.titleSmall)
                Text("• يتم مسح البيانات الحالية واستبدالها بالمستوردة\n• يدعم JSON العادي والمشفر AES-256\n• الإصدار 8 متوافق مع SCHEMA_VERSION في HTML", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
