package com.hybrid.business

import android.app.Application
import androidx.room.Room
import com.hybrid.business.data.local.AppDatabase
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class HybridApplication : Application() {
    companion object {
        lateinit var database: AppDatabase
    }
    override fun onCreate() {
        super.onCreate()
        database = Room.databaseBuilder(this, AppDatabase::class.java, "hybrid_business.db")
            .fallbackToDestructiveMigration()
            .build()
    }
}
