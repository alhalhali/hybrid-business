package com.hybrid.business.ui.screens.purchases

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hybrid.business.data.local.entity.PurchaseEntity
import com.hybrid.business.data.repository.BusinessRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PurchasesViewModel @Inject constructor(private val repo: BusinessRepository): ViewModel() {
    val purchases = repo.observePurchases()
    private fun today(): String = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
    fun addPurchase(supplier: String, item: String, qty: Double, cost: Double) = viewModelScope.launch {
        val total = qty * cost
        repo.addPurchase(PurchaseEntity(supplier=supplier, item=item, quantity=qty, unitCost=cost, total=total, subtotal=total, date=today(), status="received"))
    }
}
