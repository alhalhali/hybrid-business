package com.hybrid.business.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.hybrid.business.ui.navigation.Screen
import com.hybrid.business.util.formatCurrency

@Composable
fun HomeScreen(onNavigate: (Screen) -> Unit, vm: HomeViewModel = hiltViewModel()) {
    val state by vm.uiState.collectAsState()
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(20.dp)) {
                    Text("الرصيد الحالي", style = MaterialTheme.typography.labelMedium)
                    Text(formatCurrency(state.balance), style = MaterialTheme.typography.headlineMedium)
                    Text("إجمالي الحركة: ${formatCurrency(state.total)}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("إجمالي الوارد", formatCurrency(state.income), Modifier.weight(1f)) { onNavigate(Screen.Accounting) }
                StatCard("إجمالي المصروف", formatCurrency(state.expense), Modifier.weight(1f)) { onNavigate(Screen.Accounting) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("التزامات مستحقة", formatCurrency(state.due), Modifier.weight(1f)) { onNavigate(Screen.Workers) }
                StatCard("المشاريع", "${state.projectCount}", Modifier.weight(1f)) { onNavigate(Screen.Projects) }
            }
        }
        items(state.recent.size) { i ->
            val t = state.recent[i]
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text(t.category); Text(t.date, style = MaterialTheme.typography.bodySmall) }
                    Text(formatCurrency(t.amount), color = if(t.type=="income") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier = modifier, onClick = onClick) {
        Column(Modifier.padding(12.dp)) { Text(label, style = MaterialTheme.typography.labelSmall); Text(value, style = MaterialTheme.typography.titleMedium) }
    }
}
