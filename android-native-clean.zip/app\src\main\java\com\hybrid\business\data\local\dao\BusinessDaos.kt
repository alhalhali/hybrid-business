package com.hybrid.business.data.local.dao

import androidx.room.*
import com.hybrid.business.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY date DESC")
    fun observeAll(): Flow<List<TransactionEntity>>
    @Query("SELECT * FROM transactions WHERE projectId = :projectId")
    fun observeByProject(projectId: Long): Flow<List<TransactionEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: TransactionEntity): Long
    @Update suspend fun update(e: TransactionEntity)
    @Query("DELETE FROM transactions WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("SELECT SUM(amount) FROM transactions WHERE type='income'") fun sumIncome(): Flow<Double?>
    @Query("SELECT SUM(amount) FROM transactions WHERE type='expense'") fun sumExpense(): Flow<Double?>
}

@Dao
interface WorkerDao {
    @Query("SELECT * FROM workers ORDER BY name ASC") fun observeAll(): Flow<List<WorkerEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: WorkerEntity): Long
    @Update suspend fun update(e: WorkerEntity)
    @Query("DELETE FROM workers WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("SELECT * FROM workers WHERE id = :id") suspend fun getById(id: Long): WorkerEntity?
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY id DESC") fun observeAll(): Flow<List<ProjectEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: ProjectEntity): Long
    @Update suspend fun update(e: ProjectEntity)
    @Query("DELETE FROM projects WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("SELECT * FROM projects WHERE id = :id") suspend fun getById(id: Long): ProjectEntity?
}

@Dao
interface PhaseDao {
    @Query("SELECT * FROM phases WHERE projectId = :projectId ORDER BY orderIndex ASC")
    fun observeByProject(projectId: Long): Flow<List<PhaseEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: PhaseEntity): Long
    @Update suspend fun update(e: PhaseEntity)
    @Query("DELETE FROM phases WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("DELETE FROM phases WHERE projectId = :projectId") suspend fun deleteByProject(projectId: Long)
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY name ASC") fun observeAll(): Flow<List<CustomerEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: CustomerEntity): Long
    @Query("DELETE FROM customers WHERE id = :id") suspend fun deleteById(id: Long)
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name ASC") fun observeAll(): Flow<List<ProductEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: ProductEntity): Long
    @Query("DELETE FROM products WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("SELECT * FROM products WHERE id = :id") suspend fun getById(id: Long): ProductEntity?
    @Query("UPDATE products SET quantity = :qty WHERE id = :id") suspend fun updateQuantity(id: Long, qty: Double)
}

@Dao
interface SaleDao {
    @Query("SELECT * FROM sales ORDER BY date DESC") fun observeAll(): Flow<List<SaleEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: SaleEntity): Long
    @Query("DELETE FROM sales WHERE id = :id") suspend fun deleteById(id: Long)
}

@Dao
interface PurchaseDao {
    @Query("SELECT * FROM purchases ORDER BY date DESC") fun observeAll(): Flow<List<PurchaseEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: PurchaseEntity): Long
    @Query("DELETE FROM purchases WHERE id = :id") suspend fun deleteById(id: Long)
}

@Dao
interface SupplierDao {
    @Query("SELECT * FROM suppliers ORDER BY name ASC") fun observeAll(): Flow<List<SupplierEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: SupplierEntity): Long
    @Query("DELETE FROM suppliers WHERE id = :id") suspend fun deleteById(id: Long)
}

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts ORDER BY code ASC") fun observeAll(): Flow<List<AccountEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: AccountEntity)
    @Query("SELECT * FROM accounts WHERE code = :code LIMIT 1") suspend fun getByCode(code: String): AccountEntity?
}

@Dao
interface JournalDao {
    @Query("SELECT * FROM journal_entries ORDER BY date DESC") fun observeEntries(): Flow<List<JournalEntryEntity>>
    @Query("SELECT * FROM journal_lines WHERE entryId = :entryId") fun observeLines(entryId: Long): Flow<List<JournalLineEntity>>
    @Query("SELECT * FROM journal_lines") fun observeAllLines(): Flow<List<JournalLineEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertEntry(e: JournalEntryEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertLines(lines: List<JournalLineEntity>)
    @Query("UPDATE journal_entries SET status='void' WHERE id = :id") suspend fun voidEntry(id: Long)
}
