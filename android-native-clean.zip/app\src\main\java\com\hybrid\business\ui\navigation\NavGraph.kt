package com.hybrid.business.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.hybrid.business.ui.screens.home.HomeScreen
import com.hybrid.business.ui.screens.accounting.AccountingScreen
import com.hybrid.business.ui.screens.workers.WorkersScreen
import com.hybrid.business.ui.screens.projects.ProjectsScreen
import com.hybrid.business.ui.screens.operations.OperationsScreen
import com.hybrid.business.ui.screens.customers.CustomersScreen
import com.hybrid.business.ui.screens.products.ProductsScreen
import com.hybrid.business.ui.screens.sales.SalesScreen
import com.hybrid.business.ui.screens.purchases.PurchasesScreen
import com.hybrid.business.ui.screens.settings.SettingsScreen

sealed class Screen(val route: String, val label: String) {
    object Home : Screen("home", "الرئيسية")
    object Accounting : Screen("accounting", "الحسابات")
    object Workers : Screen("workers", "العمال")
    object Projects : Screen("projects", "المشاريع")
    object Customers : Screen("customers", "العملاء")
    object Products : Screen("products", "المنتجات")
    object Sales : Screen("sales", "المبيعات")
    object Purchases : Screen("purchases", "المشتريات")
    object Operations : Screen("operations", "التشغيل")
    object Settings : Screen("settings", "الإعدادات")
}

@Composable
fun NavGraph(navController: androidx.navigation.NavHostController) {
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) { HomeScreen(onNavigate = { navController.navigate(it.route) }) }
        composable(Screen.Accounting.route) { AccountingScreen() }
        composable(Screen.Workers.route) { WorkersScreen() }
        composable(Screen.Projects.route) { ProjectsScreen() }
        composable(Screen.Customers.route) { CustomersScreen() }
        composable(Screen.Products.route) { ProductsScreen() }
        composable(Screen.Sales.route) { SalesScreen() }
        composable(Screen.Purchases.route) { PurchasesScreen() }
        composable(Screen.Operations.route) { OperationsScreen() }
        composable(Screen.Settings.route) { SettingsScreen() }
    }
}
