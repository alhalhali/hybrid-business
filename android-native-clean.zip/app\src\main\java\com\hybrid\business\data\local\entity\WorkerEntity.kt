package com.hybrid.business.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workers")
data class WorkerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val name: String = "",
    val role: String = "general",
    val status: String = "active", // active, inactive
    val type: String = "daily", // daily, open
    val rate: Double = 0.0,
    val totalDue: Double = 0.0,
    val phone: String = "",
    val identity: String = "",
    val joinedDate: String = "",
    val notes: String = "",
    val createdAt: String = ""
)
