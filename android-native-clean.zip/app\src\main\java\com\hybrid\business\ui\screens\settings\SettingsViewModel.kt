package com.hybrid.business.ui.screens.settings

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hybrid.business.data.local.JsonImporter
import com.hybrid.business.data.repository.BusinessRepository
import com.hybrid.business.security.CryptoManager
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val repo: BusinessRepository,
    @ApplicationContext private val ctx: Context
) : ViewModel() {
    private val _msg = MutableStateFlow("")
    val msg: StateFlow<String> = _msg

    fun importJson(uri: Uri, pin: String?) {
        viewModelScope.launch {
            try {
                var json = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: throw Exception("لا يمكن قراءة الملف")
                // إذا كان مشفر (AES) فك التشفير
                if (pin != null && json.trim().startsWith("{").not()) {
                    json = CryptoManager.decrypt(json.trim(), pin) ?: throw Exception("PIN خاطئ أو ملف تالف")
                }
                val bundle = JsonImporter.parse(json)
                repo.clearAndImport(bundle.transactions, bundle.workers, bundle.projects, bundle.customers, bundle.products, bundle.sales, bundle.purchases)
                _msg.value = "✅ تم استيراد ${bundle.transactions.size} حركة و ${bundle.workers.size} عامل و ${bundle.projects.size} مشروع"
            } catch (e: Exception) {
                _msg.value = "❌ فشل الاستيراد: ${e.message}"
            }
        }
    }
}
