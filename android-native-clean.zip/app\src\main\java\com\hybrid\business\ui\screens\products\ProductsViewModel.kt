package com.hybrid.business.ui.screens.products

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hybrid.business.data.local.entity.ProductEntity
import com.hybrid.business.data.repository.BusinessRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProductsViewModel @Inject constructor(private val repo: BusinessRepository) : ViewModel() {
    val products = repo.observeProducts()
    fun addProduct(name: String, salePrice: Double, quantity: Double) = viewModelScope.launch {
        repo.addProduct(ProductEntity(name=name, salePrice=salePrice, quantity=quantity, costPrice = salePrice*0.8))
    }
    fun deleteProduct(id: Long) = viewModelScope.launch { repo.deleteProduct(id) }
}
