package com.hybrid.business

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.hybrid.business.ui.navigation.NavGraph
import com.hybrid.business.ui.navigation.Screen
import com.hybrid.business.ui.theme.HybridTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HybridTheme {
                val nav = rememberNavController()
                val drawerState = rememberDrawerState(DrawerValue.Closed)
                val scope = rememberCoroutineScope()
                val backStack by nav.currentBackStackEntryAsState()
                val currentRoute = backStack?.destination?.route

                val drawerItems = listOf(
                    Screen.Home, Screen.Accounting, Screen.Workers, Screen.Projects,
                    Screen.Customers, Screen.Products, Screen.Sales, Screen.Purchases,
                    Screen.Operations, Screen.Settings
                )

                ModalNavigationDrawer(
                    drawerState = drawerState,
                    drawerContent = {
                        ModalDrawerSheet {
                            Text("Hybrid Business OS", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(16.dp))
                            HorizontalDivider()
                            drawerItems.forEach { screen ->
                                NavigationDrawerItem(
                                    label = { Text(screen.label) },
                                    selected = currentRoute == screen.route,
                                    onClick = { scope.launch { drawerState.close() }; nav.navigate(screen.route) { launchSingleTop = true } },
                                    icon = { Icon(when(screen){
                                        is Screen.Home -> Icons.Filled.Home
                                        is Screen.Accounting -> Icons.Filled.AccountBox
                                        is Screen.Workers -> Icons.Filled.Person
                                        is Screen.Projects -> Icons.Filled.Build
                                        is Screen.Customers -> Icons.Filled.Person
                                        is Screen.Products -> Icons.Filled.Star
                                        is Screen.Sales -> Icons.Filled.Star
                                        is Screen.Purchases -> Icons.Filled.Add
                                        is Screen.Operations -> Icons.Filled.Settings
                                        else -> Icons.Filled.Settings
                                    }, null) }
                                )
                            }
                        }
                    }
                ) {
                    Scaffold(
                        topBar = {
                            @OptIn(ExperimentalMaterial3Api::class)
                            TopAppBar(
                                title = { Text(drawerItems.find{it.route==currentRoute}?.label ?: "Hybrid Business") },
                                navigationIcon = { IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Filled.Menu, null) } }
                            )
                        },
                        bottomBar = {
                            NavigationBar {
                                val bottom = listOf(Screen.Home, Screen.Accounting, Screen.Workers, Screen.Projects, Screen.Settings)
                                bottom.forEach { screen ->
                                    NavigationBarItem(
                                        selected = currentRoute == screen.route,
                                        onClick = { nav.navigate(screen.route) { launchSingleTop = true } },
                                        icon = { Icon(when(screen){
                                            is Screen.Home -> Icons.Filled.Home
                                            is Screen.Accounting -> Icons.Filled.AccountBox
                                            is Screen.Workers -> Icons.Filled.Person
                                            is Screen.Projects -> Icons.Filled.Build
                                            else -> Icons.Filled.Settings
                                        }, null) },
                                        label = { Text(screen.label, maxLines = 1) }
                                    )
                                }
                            }
                        }
                    ) { pad -> Box(Modifier.padding(pad)) { NavGraph(navController = nav) } }
                }
            }
        }
    }
}
