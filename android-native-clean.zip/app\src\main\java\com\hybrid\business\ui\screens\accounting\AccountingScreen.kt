package com.hybrid.business.ui.screens.accounting

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.hybrid.business.util.formatCurrency

@Composable
fun AccountingScreen(vm: AccountingViewModel = hiltViewModel()) {
    val txs by vm.transactions.collectAsState(emptyList())
    var filter by remember { mutableStateOf("all") }
    val filtered = when(filter){
        "income" -> txs.filter{it.type=="income"}
        "expense" -> txs.filter{it.type=="expense"}
        else -> txs
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("المحاسبة ودفتر الأستاذ", style = MaterialTheme.typography.titleLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            FilterChip(selected = filter=="all", onClick = {filter="all"}, label = {Text("الكل")})
            FilterChip(selected = filter=="income", onClick = {filter="income"}, label = {Text("واردات")})
            FilterChip(selected = filter=="expense", onClick = {filter="expense"}, label = {Text("مصروفات")})
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered) { t ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column { Text(t.category); Text(t.description, style = MaterialTheme.typography.bodySmall) }
                        Text((if(t.type=="income") "+" else "-") + formatCurrency(t.amount))
                    }
                }
            }
        }
    }
}
