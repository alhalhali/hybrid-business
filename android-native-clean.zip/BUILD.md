# تعليمات البناء

1. افتح `android-native` في Android Studio Hedgehog أو أحدث
2. سيظهر طلب `Sync Project` -> اضغط Sync
3. انتظر تحميل `Room, Hilt, Compose`
4. شغل:
```
Run > Run 'app'
```
أو من الطرفية:
```bash
./gradlew assembleDebug
```
الـ APK سيكون في `app/build/outputs/apk/debug/app-debug.apk`

## استيراد البيانات القديمة
1. من التطبيق HTML القديم: الإعدادات -> تصدير JSON
2. في التطبيق الجديد: القائمة الجانبية -> الإعدادات -> اختيار ملف JSON
3. أدخل PIN إذا كانت النسخة مشفرة -> سيتم الاستيراد تلقائياً

- يدعم الملفات العادية والمشفرة AES-256-GCM
- يتم تحويل كل الحقول تلقائياً لـ Room Entities
