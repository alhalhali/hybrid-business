package com.hybrid.business.ui.screens.operations

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier

@Composable
fun OperationsScreen() {
    var tab by remember{ mutableStateOf(0) }
    val tabs = listOf("يوميات", "حضور", "دفعات", "مخزون")
    Column {
        TabRow(selectedTabIndex = tab) { tabs.forEachIndexed{i,t-> Tab(selected=i==tab, onClick={tab=i}, text={Text(t)}) } }
        when(tab){
            0 -> Text("يوميات المشاريع - Room + Compose", modifier = Modifier.padding(16.dp))
            1 -> Text("الحضور والأجور", modifier = Modifier.padding(16.dp))
            2 -> Text("الدفعات والمستخلصات", modifier = Modifier.padding(16.dp))
            3 -> Text("المخزون - تنبيه عند الحد الأدنى", modifier = Modifier.padding(16.dp))
        }
    }
}
