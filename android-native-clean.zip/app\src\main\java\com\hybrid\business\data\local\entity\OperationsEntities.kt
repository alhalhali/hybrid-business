package com.hybrid.business.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_journals")
data class DailyJournalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val projectId: Long = 0,
    val date: String = "",
    val work: String = "",
    val notes: String = "",
    val workers: Int = 0,
    val progress: Int = 0
)

@Entity(tableName = "attendance")
data class AttendanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val workerId: Long = 0,
    val projectId: Long? = null,
    val date: String = "",
    val status: String = "present",
    val hours: Double = 8.0,
    val overtime: Double = 0.0,
    val wage: Double = 0.0,
    val notes: String = ""
)

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val projectId: Long? = null,
    val client: String = "",
    val invoiceNo: String = "",
    val amount: Double = 0.0,
    val date: String = "",
    val status: String = "pending",
    val notes: String = ""
)

@Entity(tableName = "inventory")
data class InventoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val name: String = "",
    val unit: String = "وحدة",
    val quantity: Double = 0.0,
    val minQuantity: Double = 0.0,
    val unitCost: Double = 0.0,
    val supplierId: Long? = null
)

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val code: String = "",
    val name: String = "",
    val type: String = "asset", // asset, liability, equity, revenue, expense
    val parentId: Long? = null,
    val active: Boolean = true
)

@Entity(tableName = "journal_entries")
data class JournalEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val entryNo: String = "",
    val date: String = "",
    val reference: String = "",
    val description: String = "",
    val status: String = "posted", // posted, void
    val source: String = "manual"
)

@Entity(tableName = "journal_lines")
data class JournalLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entryId: Long = 0,
    val accountId: Long = 0,
    val debit: Double = 0.0,
    val credit: Double = 0.0,
    val description: String = ""
)
