package com.hybrid.business.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val name: String = "",
    val phone: String = "",
    val email: String = "",
    val address: String = "",
    val openingBalance: Double = 0.0,
    val balance: Double = 0.0,
    val notes: String = ""
)

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val name: String = "",
    val sku: String = "",
    val barcode: String = "",
    val unit: String = "قطعة",
    val category: String = "",
    val salePrice: Double = 0.0,
    val costPrice: Double = 0.0,
    val quantity: Double = 0.0,
    val minQuantity: Double = 0.0,
    val notes: String = ""
)

@Entity(tableName = "warehouses")
data class WarehouseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val name: String = "المخزن الرئيسي",
    val code: String = "MAIN",
    val location: String = ""
)

@Entity(tableName = "sales")
data class SaleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val invoiceNo: String = "",
    val customerId: Long? = null,
    val productId: Long? = null,
    val productName: String = "",
    val quantity: Double = 0.0,
    val unitPrice: Double = 0.0,
    val subtotal: Double = 0.0,
    val taxRate: Double = 0.0,
    val taxAmount: Double = 0.0,
    val total: Double = 0.0,
    val date: String = "",
    val paymentMethod: String = "cash",
    val notes: String = "",
    val journalEntryId: Long? = null
)

@Entity(tableName = "purchases")
data class PurchaseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val supplier: String = "",
    val item: String = "",
    val quantity: Double = 0.0,
    val unitCost: Double = 0.0,
    val subtotal: Double = 0.0,
    val taxRate: Double = 0.0,
    val taxAmount: Double = 0.0,
    val total: Double = 0.0,
    val date: String = "",
    val status: String = "planned",
    val projectId: Long? = null,
    val notes: String = "",
    val transactionId: Long? = null,
    val journalEntryId: Long? = null
)

@Entity(tableName = "suppliers")
data class SupplierEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val name: String = "",
    val phone: String = "",
    val category: String = "",
    val balance: Double = 0.0,
    val notes: String = ""
)
