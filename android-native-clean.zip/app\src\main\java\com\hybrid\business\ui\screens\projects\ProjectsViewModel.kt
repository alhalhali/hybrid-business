package com.hybrid.business.ui.screens.projects

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hybrid.business.data.local.entity.ProjectEntity
import com.hybrid.business.data.repository.BusinessRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProjectsViewModel @Inject constructor(private val repo: BusinessRepository): ViewModel() {
    val projects = repo.observeProjects()
    fun addProject(name: String) = viewModelScope.launch {
        repo.addProject(ProjectEntity(name=name), emptyList())
    }
}
