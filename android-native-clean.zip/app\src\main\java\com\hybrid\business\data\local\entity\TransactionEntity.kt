package com.hybrid.business.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val type: String = "expense", // income, expense, accrual
    val amount: Double = 0.0,
    val category: String = "",
    val description: String = "",
    val date: String = "", // yyyy-MM-dd
    val workerId: Long? = null,
    val projectId: Long? = null,
    val phaseId: Long? = null,
    val taxRate: Double = 0.0,
    val taxAmount: Double = 0.0,
    val journalEntryId: Long? = null,
    val saleId: Long? = null,
    val purchaseId: Long? = null,
    val attendanceId: Long? = null,
    val paymentId: Long? = null,
    val createdAt: String = ""
)
