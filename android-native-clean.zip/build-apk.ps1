# بناء APK debug بنقرة واحدة
$ErrorActionPreference = "Stop"
$env:ANDROID_HOME = "C:\Android"
$env:ANDROID_SDK_ROOT = "C:\Android"
$env:Path += ";C:\Android\cmdline-tools\latest\bin;C:\Android\platform-tools"

$projectDir = $PSScriptRoot
Push-Location $projectDir

if (!(Test-Path ".\gradlew.bat")) {
    Write-Host "❌ gradlew غير موجود، شغل setup-sdk.ps1 أولاً" -ForegroundColor Red
    pause; exit
}

Write-Host "=== بناء APK Debug ===" -ForegroundColor Cyan
.\gradlew.bat assembleDebug --stacktrace

if (Test-Path "app\build\outputs\apk\debug\app-debug.apk") {
    $apk = "app\build\outputs\apk\debug\app-debug.apk"
    $size = (Get-Item $apk).Length / 1MB
    Write-Host "`n✅ تم البناء بنجاح!" -ForegroundColor Green
    Write-Host "المسار: $projectDir\$apk" -ForegroundColor Yellow
    Write-Host ("الحجم: {0:N2} MB" -f $size)
    # فتح المجلد
    explorer.exe "app\build\outputs\apk\debug\"
} else {
    Write-Host "`n❌ فشل البناء، راجع الأخطاء أعلاه" -ForegroundColor Red
}
Pop-Location
pause
