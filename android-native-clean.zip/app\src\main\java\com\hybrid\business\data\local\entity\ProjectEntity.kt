package com.hybrid.business.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workspaceId: String = "LOCAL-001",
    val name: String = "",
    val client: String = "",
    val budget: Double = 0.0,
    val contractValue: Double = 0.0,
    val priority: String = "medium", // low, medium, high
    val startDate: String = "",
    val endDate: String = "",
    val notes: String = "",
    val createdAt: String = ""
)

@Entity(tableName = "phases", foreignKeys = [
    androidx.room.ForeignKey(entity = ProjectEntity::class, parentColumns = ["id"], childColumns = ["projectId"], onDelete = androidx.room.ForeignKey.CASCADE)
])
data class PhaseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long = 0,
    val name: String = "",
    val budget: Double = 0.0,
    val status: String = "pending", // pending, active, done
    val orderIndex: Int = 0
)
