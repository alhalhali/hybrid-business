package com.hybrid.business.ui.screens.projects

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.hybrid.business.util.formatCurrency

@Composable
fun ProjectsScreen(vm: ProjectsViewModel = hiltViewModel()) {
    val projects by vm.projects.collectAsState(emptyList())
    var showDialog by remember{ mutableStateOf(false) }
    Scaffold(floatingActionButton = { FloatingActionButton(onClick = {showDialog=true}){ Icon(androidx.compose.material.icons.Icons.Filled.Add, null) } }) { pad ->
        LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.padding(pad).padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(projects) { p ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(p.name, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                        Text(p.client, style = MaterialTheme.typography.bodySmall)
                        LinearProgressIndicator(progress = 0.6f, modifier = Modifier.fillMaxWidth().padding(top=8.dp))
                        Text("الميزانية: ${formatCurrency(p.budget)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        if(showDialog) {
            var name by remember{ mutableStateOf("") }
            AlertDialog(onDismissRequest = {showDialog=false}, title={Text("إضافة مشروع")},
                text={ OutlinedTextField(name,{name=it}, label={Text("اسم المشروع")}) },
                confirmButton={ TextButton(onClick={vm.addProject(name); showDialog=false}){Text("حفظ")} },
                dismissButton={ TextButton(onClick={showDialog=false}){Text("إلغاء")} }
            )
        }
    }
}
