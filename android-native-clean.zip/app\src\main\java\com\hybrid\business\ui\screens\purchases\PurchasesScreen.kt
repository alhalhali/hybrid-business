package com.hybrid.business.ui.screens.purchases

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.hybrid.business.util.formatCurrency

@Composable
fun PurchasesScreen(vm: PurchasesViewModel = hiltViewModel()) {
    val purchases by vm.purchases.collectAsState(emptyList())
    var showDialog by remember{ mutableStateOf(false) }
    Scaffold(floatingActionButton={ FloatingActionButton(onClick={showDialog=true}){ Icon(Icons.Filled.Add, null) } }){ pad ->
        Column(Modifier.padding(pad).padding(16.dp)){
            Text("المشتريات والتوريد", style=MaterialTheme.typography.titleLarge)
            LazyColumn(verticalArrangement= Arrangement.spacedBy(8.dp), modifier= Modifier.padding(top=12.dp)){
                items(purchases){ p ->
                    Card(Modifier.fillMaxWidth()){
                        Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement= Arrangement.SpaceBetween){
                            Column{ Text(p.item, style=MaterialTheme.typography.titleSmall); Text("${p.supplier} • ${p.date}", style=MaterialTheme.typography.bodySmall) }
                            Text(formatCurrency(p.total), color=MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
        if(showDialog){
            var supplier by remember{ mutableStateOf("") }
            var item by remember{ mutableStateOf("") }
            var qty by remember{ mutableStateOf("1") }
            var cost by remember{ mutableStateOf("") }
            AlertDialog(onDismissRequest={showDialog=false}, title={Text("شراء جديد")},
                text={ Column(verticalArrangement= Arrangement.spacedBy(8.dp)){ OutlinedTextField(supplier,{supplier=it}, label={Text("المورد")}); OutlinedTextField(item,{item=it}, label={Text("المادة")}); OutlinedTextField(qty,{qty=it}, label={Text("الكمية")}); OutlinedTextField(cost,{cost=it}, label={Text("سعر الوحدة")}) } },
                confirmButton={ TextButton(onClick={vm.addPurchase(supplier, item, qty.toDoubleOrNull()?:1.0, cost.toDoubleOrNull()?:0.0); showDialog=false}){Text("حفظ")} },
                dismissButton={ TextButton(onClick={showDialog=false}){Text("إلغاء")} }
            )
        }
    }
}
